"""This module contains the ArmisAlerts class."""

from datetime import datetime, timedelta

from SharedCode import consts
from SharedCode.armis_api_client import ArmisApiClient
from SharedCode.checkpoint_manager import ArmisCheckpointManager
from SharedCode.exception import ArmisException
from SharedCode.logger import app_logger
from SharedCode.sentinel import MicrosoftSentinel
from SharedCode.utils import post_data_to_sentinel


class ArmisAlertsCollector:
    """Class to collect data from Armis API and post it to Sentinel."""

    def __init__(self):
        """Initialize the ArmisAlertsCollector instance.

        This method sets up the ArmisApiClient, MicrosoftSentinel and ArmisCheckpointManager instances.
        It also sets the page size for the Armis API and the offset for the first page of data.
        If a checkpoint exists, it is used to set the AQL string for the Armis API.
        If no checkpoint exists, the AQL string is set to fetch all alerts from the beginning of time.
        """
        self.checkpoint_manager = ArmisCheckpointManager(
            connection_string=consts.CONNECTION_STRING, table_name=consts.CHECKPOINT_TABLE_NAME
        )
        self.api_client = ArmisApiClient()
        self.sentinel_client = MicrosoftSentinel()
        self.page_size = consts.ARMIS_ALERTS_API_PAGE_LENGTH
        self.alerts_api_offset = 0
        checkpoint = self.checkpoint_manager.get_checkpoint(
            partition_key=consts.CHECKPOINT_TABLE_PARTITION_KEY, row_key=consts.CHECKPOINT_TABLE_ROW_KEY
        )

        if checkpoint:
            self.aql_data = f"in:alerts after:{checkpoint}"
        else:
            self.aql_data = "in:alerts"

    def get_armis_alerts_data_into_the_sentinel(self) -> None:
        """
        Fetches data from the Armis API and posts it to Sentinel.

        This method runs for a maximum of 9 minutes and 30 seconds. It fetches data from the Armis API using the AQL
        query stored in the `aql_data` attribute. The data is then posted to Sentinel using the `post_data_to_sentinel`
        method.
        If there is no more data to fetch, the `alerts_api_offset` attribute is set to `None`.

        If an error occurs while fetching data from the Armis API, an `ArmisException` is raised.

        Returns:
            None
        """
        app_logger.info("Starting to fetch data from Armis API")
        max_run_duration = timedelta(minutes=9, seconds=30)
        start_time = datetime.now()
        while (datetime.now() - start_time < max_run_duration) and (self.alerts_api_offset is not None):
            self.fetch_and_post_data()
        app_logger.info("Completed fetching data from Armis API")

    def fetch_and_post_data(self) -> None:
        """
        Fetches data from the Armis API and posts it to Sentinel.

        This method fetches data from the Armis API using the AQL query stored in the `aql_data` attribute.
        The data is then posted to Sentinel using the `post_data_to_sentinel` method.

        If there is no more data to fetch, the `alerts_api_offset` attribute is set to `None`.

        If an error occurs while fetching data from the Armis API, an `ArmisException` is raised.

        Returns:
            None
        """
        try:
            request_param = {
                "aql": self.aql_data,
                "orderBy": "time",
                "length": self.page_size,
                "from": self.alerts_api_offset,
            }
            app_logger.info(f"Fetching data from Armis API with params: {request_param}")

            response_data = self.api_client.get(endpoint=consts.ARMIS_SEARCH_ENDPOINT, params=request_param).get(
                "data", {}
            )

            if response_data:
                if response_data.get("results", []):
                    app_logger.info(f"Received {len(response_data['results'])} results from Armis API")

                    app_logger.info(
                        f"Posting data to Sentinel from offset: {self.alerts_api_offset} with aql: {self.aql_data}"
                    )
                    post_data_to_sentinel(self.sentinel_client, response_data["results"])
                    app_logger.info(
                        f"Posting data to Sentinel completed successfully with {len(response_data['results'])} records."
                    )

                    new_checkpoint_value = response_data["results"][-1]["time"][:19]
                    app_logger.info(f"Setting checkpoint to {new_checkpoint_value}")
                    self.checkpoint_manager.set_checkpoint(
                        value=new_checkpoint_value,
                        partition_key=consts.CHECKPOINT_TABLE_PARTITION_KEY,
                        row_key=consts.CHECKPOINT_TABLE_ROW_KEY,
                    )
                    app_logger.info(f"Checkpoint set to {new_checkpoint_value}")
                else:
                    app_logger.info(f"No results received from Armis API: {response_data}")
            else:
                app_logger.warning(f"No response data received from Armis API: {response_data}")

            self.alerts_api_offset = response_data.get("next", None)
        except ArmisException as e:
            raise ArmisException(e)
        except Exception as e:
            app_logger.error(f"Failed to fetch data from Armis API: {e}")
            raise ArmisException(f"Failed to fetch data from Armis API: {e}")
