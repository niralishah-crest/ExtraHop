"""Armis Skipped Alerts collector."""

import datetime

from SharedCode import consts, utils
from SharedCode.armis_api_client import ArmisApiClient
from SharedCode.checkpoint_manager import ArmisCheckpointManager
from SharedCode.exception import ArmisException
from SharedCode.logger import app_logger
from SharedCode.sentinel import MicrosoftSentinel


class ArmisSkippedAlertsCollector:
    """Armis Skipped Alerts collector."""

    def __init__(self):
        """Initialize the ArmisSkippedAlertsCollector instance.

        This method sets up the ArmisApiClient, MicrosoftSentinel and ArmisCheckpointManager instances.
        It also sets the page size for the Armis API and the offset for the first page of data.
        If a checkpoint exists, it is used to set the AQL string for the Armis API.
        If no checkpoint exists, the AQL string is set to fetch all alerts from the beginning of time.
        """
        self.checkpoint_manager = ArmisCheckpointManager(
            connection_string=consts.CONNECTION_STRING, table_name=consts.CHECKPOINT_TABLE_NAME
        )
        self.api_client = ArmisApiClient()
        self.sentinel_client = MicrosoftSentinel()
        self.page_size = consts.ARMIS_ALERTS_API_PAGE_LENGTH
        self.alerts_api_offset = 0
        self.checkpoint = self.checkpoint_manager.get_checkpoint(
            partition_key=consts.CHECKPOINT_TABLE_PARTITION_KEY, row_key=consts.CHECKPOINT_TABLE_ROW_KEY
        )

    def fetch_and_post_data(self, after_timestamp, before_timestamp):
        """
        Fetches data from the Armis API and posts it to Sentinel.

        This method fetches data from the Armis API using the AQL query stored in the `aql_data` attribute.
        The data is then posted to Sentinel using the `post_data_to_sentinel` method.

        If there is no more data to fetch, the `alerts_api_offset` attribute is set to `None`.

        If an error occurs while fetching data from the Armis API, an `ArmisException` is raised.

        Args:
            after_timestamp (str): The timestamp after which to fetch data.
            before_timestamp (str): The timestamp before which to fetch data.

        Returns:
            list: The list of data fetched from the Armis API.
        """
        self.aql_data = f"in:alerts after:{after_timestamp} before:{before_timestamp}"
        api_alerts_data = []
        while self.alerts_api_offset is not None:
            try:
                request_param = {
                    "aql": self.aql_data,
                    "orderBy": "time",
                    "length": self.page_size,
                    "from": self.alerts_api_offset,
                }
                app_logger.info(f"Fetching data from Armis API with params: {request_param}")
                response_data = self.api_client.get(endpoint=consts.ARMIS_SEARCH_ENDPOINT, params=request_param).get(
                    "data", {}
                )

                if not response_data:
                    app_logger.warning(f"No response data received from Armis API: {response_data}")
                    return None

                if response_data.get("results", []):
                    app_logger.info(f"Received {len(response_data['results'])} results from Armis API")
                    api_alerts_data.extend(response_data.get("results"))
                    self.alerts_api_offset = response_data.get("next", None)
                else:
                    app_logger.info(f"No results received from Armis API: {response_data}")
            except Exception as e:
                app_logger.error(f"Failed to fetch data from Armis API: {e}")
                raise ArmisException(f"Failed to fetch data from Armis API: {e}")
        app_logger.debug(f"Total Alerts data: {len(api_alerts_data)}")
        return api_alerts_data

    def check_condition_to_fetch_alerts_data_in_histirical_time(self, timestamp, after_timestamp, before_timestamp):
        """
        Checks the condition to fetch alerts data in historical time.

        This method checks if the timestamp is older than 2 hours.
        If it is, it means that there is no need to fetch alerts data in historical time.
        It then fetches data from the Armis Alert table using the query.
        If no data is found, it returns False.
        Otherwise, it returns True.

        Args:
            timestamp (datetime.datetime): The timestamp to check.
            after_timestamp (str): The timestamp after which to fetch data.
            before_timestamp (str): The timestamp before which to fetch data.

        Returns:
            bool: True if the condition is met, False otherwise.
        """
        if timestamp < datetime.datetime.now() - datetime.timedelta(hours=2):
            app_logger.info(
                "Checkpoint time is older than 2 hours, No need to check data in historical time. Hence, exiting."
            )
            return False, []
        app_logger.info(f"Fetching data from Armis Alert table after timestamp: {after_timestamp}")
        query = consts.ARMIS_ALERTS_QUERY.format(
                    f"{consts.ARMIS_ALERTS_TABLE}_CL",
                    after_timestamp,
                    before_timestamp,
                )
        app_logger.info(f"Query: {query}")
        table_alerts_data, flag = utils.get_logs_data(
                query=query
            )
        if not flag:
            return False, []

        table_alerts_data = [alert_data.get("alertId_d") for alert_data in table_alerts_data]
        app_logger.info(f"Alerts data: {table_alerts_data}")
        return True, table_alerts_data

    def get_skipped_armis_alerts_data_into_the_sentinel(self) -> None:
        """
        Checks the checkpoint time to find the lagging period and fetches data from Armis API and posts it to Sentinel.

        This method checks if the checkpoint time is older than 2 hours.
        If it is, it means that there is no need to fetch alerts data in historical time.
        It then fetches data from the Armis Alert table using the query.
        If no data is found, it returns False.
        Otherwise, it returns True.

        If there is no more data to fetch, the `alerts_api_offset` attribute is set to `None`.

        If an error occurs while fetching data from the Armis API, an `ArmisException` is raised.

        Returns:
            None
        """
        app_logger.info("Checking the checkpoint time to find the lagging period")
        if not self.checkpoint:
            app_logger.info("No checkpoint time received from the ArmisAlertsCheckpoint table. Hence, exiting.")
            return
        timestamp = datetime.datetime.strptime(self.checkpoint, consts.TIME_FORMAT)
        app_logger.info(f"Checkpoint time received from the ArmisAlertsCheckpoint table: {timestamp}")
        after_timestamp = (timestamp - datetime.timedelta(hours=2)).strftime(consts.TIME_FORMAT)
        before_timestamp = timestamp.strftime(consts.TIME_FORMAT)
        check_flag, table_alerts_data = self.check_condition_to_fetch_alerts_data_in_histirical_time(
            timestamp, after_timestamp, before_timestamp
        )
        if not check_flag:
            app_logger.info(
                "Condition to check data in historical time is not met. No need to check data in historical time. Hence, exiting."
            )
            return
        app_logger.debug(f"Alerts Table data: {table_alerts_data}")
        api_alerts_data = self.fetch_and_post_data(after_timestamp, before_timestamp)
        if not api_alerts_data:
            app_logger.info("No data received from Armis API. Hence, exiting.")
            return
        api_alerts_ids = set(alert.get("alertId") for alert in api_alerts_data)
        app_logger.debug(f"Total Alerts from Armis API: {len(api_alerts_ids)}")
        skipped_alerts = self.get_difference_data(api_alerts_ids, table_alerts_data, api_alerts_data)
        if not skipped_alerts:
            app_logger.info("No skipped alerts found. Hence, exiting.")
            return
        app_logger.info(f"Total skipped alerts: {len(skipped_alerts)}")
        app_logger.info(f"Posting remaining data to Sentinel between {after_timestamp} and {before_timestamp}")
        utils.post_data_to_sentinel(self.sentinel_client, skipped_alerts)
        app_logger.info(f"Completed fetching data from Armis API between {after_timestamp} and {before_timestamp}")

    def get_difference_data(self, api_alerts_ids, table_alerts_data, api_alerts_data):
        """
        Finds the difference between the alerts received from the Armis API and the Armis Alert table.

        Args:
            api_alerts_ids (set): The set of alert IDs received from the Armis API.
            table_alerts_data (set): The set of alert IDs in the Armis Alert table.
            api_alerts_data (dict): The dictionary of alert data received from the Armis API, keyed by alert ID.

        Returns:
            list: The list of alert data that are in the Armis API but not in the Armis Alert table.
        """
        skipped_alert_ids = list(set(api_alerts_ids).difference(set(table_alerts_data)))
        app_logger.debug(f"Alert IDs to be ingested from past: {skipped_alert_ids}")
        skipped_alerts = [alert for alert in api_alerts_data if alert.get("alertId") in skipped_alert_ids]
        return skipped_alerts
