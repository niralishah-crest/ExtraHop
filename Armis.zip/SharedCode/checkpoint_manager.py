"""This module is for checkpoint manager of Armis."""

from azure.core.exceptions import ResourceNotFoundError
from azure.data.tables import TableServiceClient, UpdateMode

from SharedCode.exception import ArmisException
from SharedCode.logger import app_logger


class ArmisCheckpointManager:
    """Class to manage checkpoints in Azure Table Storage."""

    def __init__(self, connection_string: str, table_name: str):
        """
        Initialize the CheckpointManager instance.

        Args:
            connection_string (str): The connection string to the Azure Table Storage.
            table_name (str): The name of the table to store the checkpoint.

        Raises:
            ArmisException: If the table could not be created due to a storage error.
        """
        self.connection_string = connection_string
        self.table_name = table_name
        self.service_client = TableServiceClient.from_connection_string(conn_str=self.connection_string)
        self.table_client = self._get_or_create_table()

    def _get_or_create_table(self) -> TableServiceClient:
        """
        Accesses or creates the specified Azure Table Storage table.

        This method attempts to access the table with the name specified by `self.table_name`.
        If the table does not exist, it will be created.

        Returns:
            TableServiceClient: The table client for the specified table.

        Raises:
            ArmisException: If there is an error creating or accessing the table.
        """
        try:
            app_logger.debug(f"Accessing table : {self.table_name}")
            table_client = self.service_client.create_table_if_not_exists(self.table_name)
            return table_client
        except Exception as e:
            app_logger.error(f"Error creating or accessing table: {e}")
            raise ArmisException(f"Error creating or accessing table: {e}")

    def get_checkpoint(self, partition_key: str, row_key: str) -> str:
        """
        Retrieves the checkpoint value associated with the specified partition key and row key.

        Args:
            partition_key (str): The partition key of the checkpoint to retrieve.
            row_key (str): The row key of the checkpoint to retrieve.

        Returns:
            str: The value of the checkpoint if it exists, otherwise None.

        Raises:
            ArmisException: If there is an error retrieving the checkpoint.
        """
        try:
            app_logger.debug("Getting checkpoint")
            entity = self.table_client.get_entity(partition_key=partition_key, row_key=row_key)
            return entity.get("Value")
        except ResourceNotFoundError:
            app_logger.warning("Checkpoint not found")
            return None
        except Exception as e:
            app_logger.error(f"Error getting checkpoint: {e}")
            raise ArmisException(f"Error getting checkpoint: {e}")

    def set_checkpoint(self, partition_key: str, row_key: str, value: str) -> None:
        """
        Sets the checkpoint value associated with the specified partition key and row key.

        Args:
            partition_key (str): The partition key of the checkpoint to set.
            row_key (str): The row key of the checkpoint to set.
            value (str): The value to set the checkpoint to.

        Raises:
            ArmisException: If there is an error setting the checkpoint.
        """
        app_logger.debug(f"Setting checkpoint to {value}")
        entity = {"PartitionKey": partition_key, "RowKey": row_key, "Value": value}
        try:
            self.table_client.upsert_entity(mode=UpdateMode.MERGE, entity=entity)
        except Exception as e:
            app_logger.error(f"Error setting checkpoint: {e}")
            raise ArmisException(f"Error setting checkpoint: {e}")

    def delete_checkpoint(self, partition_key: str, row_key: str) -> None:
        """
        Deletes the checkpoint associated with the specified partition key and row key.

        Args:
            partition_key (str): The partition key of the checkpoint to delete.
            row_key (str): The row key of the checkpoint to delete.

        Raises:
            ArmisException: If there is an error deleting the checkpoint.
        """
        try:
            app_logger.debug("Deleting checkpoint")
            self.table_client.delete_entity(partition_key=partition_key, row_key=row_key)
        except ResourceNotFoundError:
            app_logger.warning("Checkpoint not found")
        except Exception as e:
            app_logger.error(f"Error deleting checkpoint: {e}")
            raise ArmisException(f"Error deleting checkpoint: {e}")
