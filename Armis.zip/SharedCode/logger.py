"""This module contains the logger for the Armis Connector."""

import logging
import os
import sys

from SharedCode import consts


class ArmisLogFormatter(logging.Formatter):
    """Class to format the log messages"""

    def format(self, record: logging.LogRecord) -> str:
        """
        Format the log message.

        This method formats the log message by extracting the calling
        class name, function name, log level, and the log message itself.

        Args:
            record (logging.LogRecord): The log record to be formatted.

        Returns:
            str: The formatted log message.
        """
        # Format the log message
        file_name = os.path.basename(record.pathname)
        func_name = record.funcName
        message = record.getMessage()

        # Construct the log format
        log_format = consts.ARMIS_LOG_FORMAT.format(file_name=file_name, func_name=func_name, message=message)

        record.msg = log_format
        record.args = ()

        return log_format


level_str = consts.ARMMIS_LOG_LEVEL.upper()
level = getattr(logging, level_str, logging.INFO)

app_logger = logging.getLogger(consts.AZURE_LOGGER_NAME)
app_logger.setLevel(level)

console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(ArmisLogFormatter())
app_logger.addHandler(console_handler)
