"""This module is for posting data into log Analytics workspace."""

import base64
import datetime
import hashlib
import hmac
import socket
import time

import requests
from requests.adapters import HTTPAdapter
from urllib3.exceptions import NameResolutionError
from urllib3.util import Retry

from SharedCode import consts
from SharedCode.exception import ArmisException
from SharedCode.logger import app_logger

customer_id = consts.WORKSPACE_ID
shared_key = consts.WORKSPACE_KEY


class DNSRetryAdapter(HTTPAdapter):
    """DNSRetryAdapter class is used to retry DNS resolution failures."""

    def send(self, request, **kwargs):
        """Sends a request with DNS resolution retry.

        Args:
            request: Prepared request object to send
            **kwargs: Additional keyword arguments to pass to super().send

        Returns:
            Response object

        Raises:
            requests.exceptions.RetryError: If DNS resolution fails
        """
        try:
            return super().send(request, **kwargs)
        except requests.exceptions.ConnectionError as e:
            if isinstance(e.__cause__, socket.gaierror):
                raise requests.exceptions.RetryError(f"DNS resolution failed: {e}") from e
            raise


class MicrosoftSentinel:
    """MicrosoftSentinel class is used to post data into log Analytics workspace."""

    def __init__(self):
        """Initialize the MicrosoftSentinel client with retry configuration."""
        # Set up the session with retry logic
        self.session = requests.Session()

        # Configure retry strategy
        retry_strategy = Retry(
            total=consts.SENTINEL_API_RETRY_COUNT,
            connect=consts.SENTINEL_API_RETRY_COUNT,
            read=consts.SENTINEL_API_RETRY_COUNT,
            backoff_factor=2,
            status_forcelist=[429, 500, 503],
            allowed_methods=["POST"],
            raise_on_status=False,
        )

        adapter = DNSRetryAdapter(max_retries=retry_strategy)
        self.session.mount("https://", adapter)

    def build_signature(
        self,
        date,
        content_length,
        method,
        content_type,
        resource,
    ):
        """To build signature which is required in header."""
        x_headers = "x-ms-date:" + date
        string_to_hash = method + "\n" + str(content_length) + "\n" + content_type + "\n" + x_headers + "\n" + resource
        bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
        decoded_key = base64.b64decode(shared_key)
        encoded_hash = base64.b64encode(
            hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()
        ).decode()
        authorization = f"SharedKey {customer_id}:{encoded_hash}"
        return authorization

    def post_data(self, body, log_type):
        """Build and send a request to the POST API with automatic retries."""
        method = "POST"
        content_type = "application/json"
        resource = "/api/logs"
        rfc1123date = datetime.datetime.now(datetime.timezone.utc).strftime("%a, %d %b %Y %H:%M:%S GMT")
        content_length = len(body)

        try:
            signature = self.build_signature(
                rfc1123date,
                content_length,
                method,
                content_type,
                resource,
            )
        except Exception as err:
            app_logger.error(f"Error occurred for build signature, Issue with Microsoft Sentinel Credentials : {err}")
            raise ArmisException("Error while generating signature for posting data into log analytics.")

        try:

            uri = f"https://{consts.WORKSPACE_ID}.ods.opinsights.azure.com{resource}?api-version=2016-04-01"

            headers = {
                "content-type": content_type,
                "Authorization": signature,
                "Log-Type": log_type,
                "x-ms-date": rfc1123date,
            }

            start_time = time.time()
            # Use the session with configured retry
            response = self.session.post(uri, data=body, headers=headers, timeout=consts.REQUEST_TIMEOUT)
            duration = time.time() - start_time
            app_logger.debug(f"Response Time for sending data to Microsoft Sentinel: {duration:.3f} sec")

            # Handle response
            if 200 <= response.status_code < 300:
                app_logger.debug(f"{response.status_code} Accepted: Data Posted Successfully to Microsoft Sentinel.")
                return response.status_code
            else:
                app_logger.error(f"Error posting data to Microsoft Sentinel: {response.status_code} {response.text}")
                if response.status_code == 400:
                    app_logger.error(
                        f"Error occurred: Response code: {response.status_code} Bad Request while posting data to log"
                        f" analytics.\nError: {response.content}"
                    )
                    raise ArmisException("Invalid data format for Microsoft Sentinel.")
                elif response.status_code == 403:
                    app_logger.error(
                        "Error occurred for build signature: Issue with WorkspaceKey. Kindly verify your WorkspaceKey."
                    )
                    raise ArmisException(
                        "Error occurred for build signature: Issue with WorkspaceKey. Kindly verify your WorkspaceKey."
                    )
                else:
                    raise ArmisException(
                        f"Failed to post data to Microsoft Sentinel. Status code: {response.status_code}"
                    )

        except (requests.exceptions.ConnectionError, NameResolutionError) as e:
            app_logger.error(f"Connection error with Microsoft Sentinel: {e}")
            raise ArmisException(f"Failed to connect to Microsoft Sentinel: {e}")
        except Exception as e:
            app_logger.error(f"Unexpected error posting to Microsoft Sentinel: {e}")
            raise ArmisException(f"Unexpected error: {e}")
