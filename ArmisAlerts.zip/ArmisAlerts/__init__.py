import time

import azure.functions as func
from SharedCode.logger import app_logger

from ArmisAlerts.armis_alerts_collector import ArmisAlertsCollector


def main(mytimer: func.TimerRequest) -> None:
    """
    Timer triggered function to ingest alerts data from Armis API into Sentinel.

    Parameters:
        mytimer (func.TimerRequest): Timer object containing information about the timer that triggered the function.

    Returns:
        None
    """
    start_time = time.time()
    app_logger.info("Execution Started")
    armis_alerts_collector = ArmisAlertsCollector()
    armis_alerts_collector.get_armis_alerts_data_into_the_sentinel()
    duration = time.time() - start_time
    app_logger.info(f"Time taken to ingest Alerts data is {duration:.3f} seconds.")
    if mytimer.past_due:
        app_logger.info("The timer is past due.")
