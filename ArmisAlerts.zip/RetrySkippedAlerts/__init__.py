import datetime
import time

import azure.functions as func
from SharedCode.logger import app_logger

from RetrySkippedAlerts.armis_skipped_alerts_collector import ArmisSkippedAlertsCollector


def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    start_time = time.time()
    app_logger.info("Execution Started")
    armis_alerts_collector = ArmisSkippedAlertsCollector()
    armis_alerts_collector.get_skipped_armis_alerts_data_into_the_sentinel()
    duration = time.time() - start_time
    app_logger.info(f"Time taken to ingest Alerts data is {duration:.3f} seconds.")
    if mytimer.past_due:
        app_logger.info("The timer is past due!")

    app_logger.info("Python timer trigger function ran at %s", utc_timestamp)
