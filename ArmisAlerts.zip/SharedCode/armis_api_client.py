"""This module is for armis api client."""

import json
import time
from datetime import datetime, timezone
from urllib.parse import urlparse

import requests
from requests.adapters import HTTPAdapter
from urllib3 import Retry

from SharedCode import consts
from SharedCode.exception import ArmisException
from SharedCode.keyvault_manager import KeyVaultManager
from SharedCode.logger import app_logger


class ArmisApiClient:
    """class for armis api client."""

    def __init__(self):
        """
        Initializes the ArmisApiClient instance.

        This method sets up the Armis base URL, requests Session instance, retry strategy and KeyVaultManager instance.
        It also checks the existing access token in the Key Vault and updates the session headers with the token.
        If the token is invalid or missing, it fetches a new token from the Armis API and updates the Key Vault and
        the session headers.
        """
        self._validate_base_url(consts.ARMIS_URL)
        self.base_url = consts.ARMIS_URL.rstrip("/")
        self.session = requests.Session()
        self._setup_retry_strategy()
        self.key_vault_manager = KeyVaultManager()
        token = self.key_vault_manager.get_secret_from_key_vault(
            secret_name=consts.ARMIS_KEY_VAULT_KEY_FOR_ACCESS_TOKEN
        )
        token_expiry = self.key_vault_manager.get_secret_from_key_vault(
            secret_name=consts.ARMIS_KEY_VAULT_KEY_FOR_ACCESS_TOKEN_EXPIRY
        )
        if self._check_token_validity(token, token_expiry):
            self.session.headers.update({"Authorization": token})
        else:
            token_data = self._fetch_token_and_update_key_vault()
            self.session.headers.update({"Authorization": token_data["access_token"]})

    def _validate_base_url(self, url: str) -> None:
        """Validate Armis base URL

        Args:
            url (str): The URL to be validated

        Raises:
            ArmisException: If the URL is invalid
        """
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            raise ArmisException(
                f"Invalid Armis URL: {url}. Must start with http:// or https:// and contain a valid host."
            )

    def _setup_retry_strategy(self) -> None:
        """Sets up the retry strategy for the requests session.

        The retry strategy is configured to retry a total of 3 times with a
        backoff factor of 5 seconds. The retry strategy will only retry the
        request if the status code is in the status_forcelist (429, 500, 503).
        The retry strategy will also retry the request if there is a connection
        error or a read timeout.

        The retry strategy is applied to both the "https" and "http" adapters.
        """
        retry_strategy = Retry(
            total=consts.ARMIS_API_RETRY_COUNT,
            connect=consts.ARMIS_API_RETRY_COUNT,
            read=consts.ARMIS_API_RETRY_COUNT,
            backoff_factor=5,
            status_forcelist=[429, 500, 503],
            allowed_methods=["GET", "POST"],
            raise_on_status=False,
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("https://", adapter)
        self.session.mount("http://", adapter)

    def _fetch_token_and_update_key_vault(self) -> str:
        """
        Fetches the access token and updates the key vault with the access token and its expiration time.

        Returns:
            str: The access token

        Raises:
            ArmisException: If there is an error fetching the access token or updating the key vault
        """
        try:
            # Fetch the access token
            auth_url = f"{self.base_url}/{consts.ARMIS_ACCESS_TOKEN_ENDPOINT.lstrip('/')}"
            app_logger.debug(f"Fetching access token using URL : {auth_url}")
            response = self.session.post(
                auth_url, data={"secret_key": consts.ARMIS_API_KEY}, timeout=consts.REQUEST_TIMEOUT
            )
            response.raise_for_status()

            # Update the key vault
            response_data = response.json().get("data", {})
            if not response_data.get("access_token"):
                app_logger.error(f"Access token not found in auth response for URL : {auth_url}")
                raise ValueError("Token not found in auth response")
            app_logger.debug("Access token fetched successfully")
            self.key_vault_manager.set_secret_into_key_vault(
                secret_name=consts.ARMIS_KEY_VAULT_KEY_FOR_ACCESS_TOKEN,
                value=response_data
            )
            self.key_vault_manager.set_secret_into_key_vault(
                secret_name=consts.ARMIS_KEY_VAULT_KEY_FOR_ACCESS_TOKEN_EXPIRY,
                value=response_data["expiration_utc"]
            )
            app_logger.debug("Access token stored in key vault successfully")

            return response_data
        except json.JSONDecodeError as e:
            app_logger.error(f"JSON decode error : {e}.")
            ArmisException(f"JSON decode error : {e}.")
        except KeyError as e:
            app_logger.error(f"Key error : {e}.")
            raise ArmisException(f"Key error : {e}.")
        except ValueError as e:
            raise ArmisException(e)
        except Exception as e:
            app_logger.error(f"Error while generating the access token : {e}.")
            raise ArmisException(f"Error while generating the access token : {e}.")

    def _refresh_token(self) -> None:
        """
        Refreshes the access token used in the session if it is near expiration.

        If the token is valid and different from the one in the session, it updates the session.
        Otherwise, it fetches a new token and updates the session and key vault.
        """
        token = self.key_vault_manager.get_secret_from_key_vault(
            secret_name=consts.ARMIS_KEY_VAULT_KEY_FOR_ACCESS_TOKEN
        )
        token_expiry = self.key_vault_manager.get_secret_from_key_vault(
            secret_name=consts.ARMIS_KEY_VAULT_KEY_FOR_ACCESS_TOKEN_EXPIRY
        )
        session_auth = self.session.headers.get("Authorization", "")
        is_token_valid = self._check_token_validity(token, token_expiry)

        if is_token_valid and session_auth != token:
            app_logger.debug("Token is valid and different from the one in the session")
            self.session.headers.update({"Authorization": token})
        else:
            app_logger.debug("Token is not valid or different from the one in the session")
            token_data = self._fetch_token_and_update_key_vault()
            self.session.headers.update({"Authorization": token_data["access_token"]})

    def _check_token_validity(self, token: str, token_expiry: str) -> bool:
        """
        Checks if the given token is valid by comparing its expiry time to the current time.

        Args:
            token (str): The token to check.
            token_expiry (str): The expiry time of the token in ISO 8601 format.

        Returns:
            bool: True if the token is valid, False otherwise.
        """
        try:
            token_expiry = datetime.fromisoformat(token_expiry)
            return token and (token_expiry > datetime.now(timezone.utc))
        except (ValueError, TypeError):
            app_logger.warning("Invalid expiry time format in Key Vault")
            return False

    def with_token_refresh(func):
        """This decorator is used to retry failed requests due to invalid access token.

        If a request fails with a 401 Unauthorized status code and the response text contains the string "invalid
        access token", the decorator will retry the request up to `consts.ARMIS_RETRY_COUNT_401` times. If the
        maximum number of retries is
        exceeded, the decorator will raise a `RuntimeError`.

        The decorator will also call `_refresh_token` to fetch a new access token before retrying the request.

        Usage:

        @with_token_refresh
        def my_method(self):
            # Make a request to Armis API
            pass

        """

        def wrapper(self, *args, **kwargs):
            """
            This function wraps the given function and retries failed requests due to invalid access token.

            If a request fails with a 401 Unauthorized status code and the response text contains the string "invalid
            access token", the wrapper will retry the request up to `consts.ARMIS_RETRY_COUNT_401` times. If the
            maximum number of retries is
            exceeded, the wrapper will raise a `RuntimeError`.

            The wrapper will also call `_refresh_token` to fetch a new access token before retrying the request.

            Args:
                *args: The positional arguments to be passed to the wrapped function.
                **kwargs: The keyword arguments to be passed to the wrapped function.

            Returns:
                The response of the wrapped function.

            Raises:
                RuntimeError: If the maximum token refresh attempts are exceeded (401 Unauthorized).
            """
            max_retries = consts.ARMIS_RETRY_COUNT_401
            for attempt in range(max_retries):
                response = func(self, *args, **kwargs)
                if response.status_code == 401:
                    if attempt < max_retries - 1:
                        self._refresh_token()
                        continue
                    else:
                        raise RuntimeError("Maximum token refresh attempts exceeded (401 Unauthorized).")
                return response
            raise RuntimeError("Unexpected error in token refresh wrapper.")

        return wrapper

    @with_token_refresh
    def make_rest_call(self, endpoint, method="GET", params=None, data=None, json=None, headers=None):
        """Makes a request to the Armis API.

        This method makes a request to the Armis API and handles any exceptions that may occur. If the request
        fails with a 401 Unauthorized status code and the response text contains the string "invalid access token",
        the `with_token_refresh` decorator will retry the request up to `consts.ARMIS_RETRY_COUNT_401` times. If
        the maximum number of retries is exceeded, the decorator will raise a `RuntimeError`.

        Args:
            endpoint (str): The API endpoint to call.
            method (str): The HTTP method to use for the request. Defaults to "GET".
            params (dict): The query parameters to include in the request.
            data (dict or bytes): The request body to send with the request.
            json (dict): The JSON data to send with the request.
            headers (dict): The headers to include in the request.

        Returns:
            requests.Response: The response from the Armis API.

        Raises:
            ArmisException: If the request fails (e.g. connection error, timeout, invalid access token).
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        try:
            app_logger.debug(f"Making {method.upper()} request to {url}.")
            start_time = time.time()
            response = self.session.request(
                method=method.upper(),
                url=url,
                params=params,
                data=data,
                json=json,
                headers=headers,
                timeout=consts.REQUEST_TIMEOUT,
            )
            duration = time.time() - start_time
            app_logger.debug(f"Response status code  : {response.status_code}")
            app_logger.debug(f"Response duration     : {duration:.3f} seconds")
            app_logger.debug(f"Response content size : {len(response.content)} bytes")
            if response.status_code == 200:
                return response
            elif response.status_code == 401:
                app_logger.error(f"API call failed: {response.text}")
                return response
            else:
                app_logger.error(f"API call failed: {response.text}")
                raise ArmisException(f"API call failed: {response.text}")
        except requests.exceptions.ConnectionError as e:
            app_logger.error(f"API call failed: connection error - {e}")
            raise ArmisException(f"API call failed: connection error - {e}")
        except requests.exceptions.Timeout as e:
            app_logger.error(f"API call failed: timeout - {e}")
            raise ArmisException(f"API call failed: timeout - {e}")
        except requests.exceptions.RequestException as e:
            app_logger.error(f"API call failed: {e}")
            raise ArmisException(f"API call failed: {e}")

    def get(self, endpoint: str, params: dict = None, headers: dict = None):
        """Makes a GET request to the specified endpoint.

        Args:
            endpoint (str): The API endpoint to call.
            params (dict): The query parameters to include in the request.
            headers (dict): The headers to include in the request.

        Returns:
            dict: The JSON response from the Armis API.

        Raises:
            ArmisException: If the request fails or if the response is not valid JSON.
        """
        try:
            app_logger.info(f"Making GET request to {endpoint} with params: {params}")
            response = self.make_rest_call(endpoint, method="GET", params=params, headers=headers)
            app_logger.info(f"GET request to {endpoint} completed successfully")
            return response.json()
        except json.JSONDecodeError as e:
            app_logger.error(f"Failed to decode JSON response: {e}")
            raise ArmisException(f"Failed to decode JSON response: {e}")
        except Exception as e:
            app_logger.error(f"Failed to make GET request: {e}")
            raise ArmisException(f"Failed to make GET request: {e}")

    def post(self, endpoint, data=None, headers=None):
        """Makes a POST request to the specified endpoint.

        Args:
            endpoint (str): The API endpoint to call.
            data (dict or bytes): The request body to send with the request.
            headers (dict): The headers to include in the request.

        Returns:
            dict: The JSON response from the Armis API.

        Raises:
            ArmisException: If the request fails or if the response is not valid JSON.
        """
        try:
            app_logger.info(f"Making POST request to {endpoint} with data: {data}")
            response = self.make_rest_call(endpoint, method="POST", data=data, headers=headers)
            app_logger.info(f"POST request to {endpoint} completed successfully")
            return response.json()
        except json.JSONDecodeError as e:
            app_logger.error(f"Failed to decode JSON response: {e}")
            raise ArmisException(f"Failed to decode JSON response: {e}")
        except Exception as e:
            app_logger.error(f"Failed to make POST request: {e}")
            raise ArmisException(f"Failed to make POST request: {e}")
