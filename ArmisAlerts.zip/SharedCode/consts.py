"""Module for constants."""

import os

# Armis constants
ARMIS_API_KEY = os.environ.get("ArmisSecretKey", "")
ARMIS_URL = os.environ.get("ArmisURL", "")
ARMIS_ALERTS_API_PAGE_LENGTH = 1000
ARMIS_ACCESS_TOKEN_ENDPOINT = "/api/v1/access_token/"
ARMIS_SEARCH_ENDPOINT = "/api/v1/search/"
ARMIS_RETRY_COUNT_401 = 3
AZURE_LOGGER_NAME = "azure"
ARMMIS_LOG_LEVEL = os.environ.get("LogLevel", "INFO")
ARMIS_LOG_FORMAT = "Armis Connector : {file_name} : {func_name} - {message}"
ARMIS_API_RETRY_COUNT = 3
ARMIS_KEY_VAULT_NAME = os.environ.get("KeyVaultName")
ARMIS_KEY_VAULT_KEY_FOR_ACCESS_TOKEN = "armis-access-token"
ARMIS_KEY_VAULT_KEY_FOR_ACCESS_TOKEN_EXPIRY = "armis-access-token-expiry"

# Microsoft Sentinel constants
CONNECTION_STRING = os.environ.get("AzureWebJobsStorage", "")
ARMIS_ALERTS_TABLE = os.environ.get("ArmisAlertsTableName", "")
WORKSPACE_ID = os.environ.get("WorkspaceID", "")
WORKSPACE_KEY = os.environ.get("WorkspaceKey", "")
AZURE_CLIENT_ID = os.environ.get("AZURE_CLIENT_ID", "")
AZURE_CLIENT_SECRET = os.environ.get("AZURE_CLIENT_SECRET", "")
AZURE_TENANT_ID = os.environ.get("AZURE_TENANT_ID", "")

# General constants
REQUEST_TIMEOUT = 180
CHECKPOINT_TABLE_NAME = "ArmisAlertsCheckpoint"
CHECKPOINT_TABLE_PARTITION_KEY = "armisalert"
CHECKPOINT_TABLE_ROW_KEY = "alertcheckpoint"
SENTINEL_API_RETRY_COUNT = 3
ARMIS_ALERTS_QUERY = """
{}
| where time_t between (todatetime({}) .. todatetime({}))
| distinct alertId_d
"""
TIME_FORMAT = "%Y-%m-%dT%H:%M:%S"
