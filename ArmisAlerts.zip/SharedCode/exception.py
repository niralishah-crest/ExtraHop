"""ArmisException module is for generating exception."""


class ArmisException(Exception):
    """Exception class to handle Armis Exceptions."""

    def __init__(self, message: str = ""):
        """Initialize exception with custom message."""
        self.message = message
        super().__init__(message)
