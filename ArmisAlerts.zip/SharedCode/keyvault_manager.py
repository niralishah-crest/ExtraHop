"""This module provides functionality to manage Azure Key Vault."""

from azure.core.exceptions import (ClientAuthenticationError,
                                   HttpResponseError, ResourceNotFoundError)
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

from SharedCode import consts
from SharedCode.exception import ArmisException
from SharedCode.logger import app_logger


class KeyVaultManager:
    """Class to manage Azure Key Vault for Armis Access Token."""

    def __init__(self):
        """
        Initializes the KeyVaultManager instance.

        This method sets the Key Vault name, the key name for the Armis access token, the URL of the Key Vault, and
        the credential to use when connecting to the Key Vault. It then creates a SecretClient instance to interact
        with the Key Vault. Finally, it validates the connection to the Key Vault.

        Raises:
            ArmisException: If there is an error connecting to the Key Vault or if the specified key does not exist in
                the Key Vault.
        """
        self.key_vault_name = consts.ARMIS_KEY_VAULT_NAME
        self.vault_url = f"https://{self.key_vault_name}.vault.azure.net"
        self.credential = DefaultAzureCredential()
        self.secret_client = SecretClient(vault_url=self.vault_url, credential=self.credential)
        self._validate_key_vault_connection()

    def _validate_key_vault_connection(self) -> None:
        """
        Validates the connection to the specified Key Vault.

        This method attempts to list the properties of secrets in the specified Key Vault.
        If the attempt fails, it raises an ArmisException with an appropriate error message.

        Raises:
            ArmisException: If there is an error connecting to the Key Vault.
        """
        try:
            list(self.secret_client.list_properties_of_secrets())
            app_logger.info(f"Connected to Key Vault '{self.key_vault_name}' successfully.")
        except ClientAuthenticationError as e:
            app_logger.error(f"Authentication failed for Key Vault '{self.key_vault_name}': {e}")
            raise ArmisException(f"Authentication failed for Key Vault '{self.key_vault_name}': {e}")
        except HttpResponseError as e:
            app_logger.error(f"Unable to access Key Vault '{self.key_vault_name}': {e}")
            raise ArmisException(f"Unable to access Key Vault '{self.key_vault_name}': {e}")
        except Exception as e:
            app_logger.error(f"Unexpected error while connecting to Key Vault '{self.key_vault_name}': {e}")
            raise ArmisException(f"Unexpected error while connecting to Key Vault '{self.key_vault_name}': {e}")

    def set_secret_into_key_vault(self, secret_name: str, value: str) -> None:
        try:
            self.secret_client.set_secret(secret_name, value)
            app_logger.info(f"Secret '{secret_name}' set successfully.")
        except HttpResponseError as e:
            app_logger.error(f"Failed to set secret '{secret_name}': {e.message}")
            raise ArmisException(f"Failed to set secret '{secret_name}': {e.message}")
        except Exception as e:
            app_logger.error(f"Unexpected error while setting secret '{secret_name}': {e}")
            raise ArmisException(f"Unexpected error while setting secret '{secret_name}': {e}")

    def get_secret_from_key_vault(self, secret_name: str) -> str:
        try:
            secret = self.secret_client.get_secret(secret_name)
            app_logger.info(f"Secret '{secret_name}' retrieved successfully.")
            return secret.value
        except ResourceNotFoundError:
            app_logger.warning(f"Secret '{secret_name}' not found in Key Vault.")
            return ""
        except HttpResponseError as e:
            app_logger.error(f"Failed to get secret '{secret_name}': {e.message}")
            raise ArmisException(f"Failed to get secret '{secret_name}': {e.message}")
        except Exception as e:
            app_logger.error(f"Unexpected error while getting secret '{secret_name}': {e}")
            raise ArmisException(f"Unexpected error while getting secret '{secret_name}': {e}")
