"""This file contains utils data"""

import json

from azure.core.exceptions import HttpResponseError
from azure.identity import DefaultAzureCredential
from azure.monitor.query import LogsQueryClient, LogsQueryStatus

from SharedCode import consts
from SharedCode.exception import ArmisException
from SharedCode.logger import app_logger
from SharedCode.sentinel import MicrosoftSentinel


def process_response(result_data):
    """Process the LogsQueryClient response and return the table data as a list of dictionaries.

    The list will contain dictionaries where the keys are the column names and the values are the
    corresponding row data.

    Args:
        response (LogsQueryClient response): The response from the LogsQueryClient.

    Returns:
        list: A list of dictionaries containing the table data.
    """
    if not result_data or not result_data.rows:
        return []
    result = [row._row_dict for row in result_data.rows]
    return result


def get_logs_data(query):
    """
    Executes a query in the Log Analytics Workspace and returns the results as a list of dictionaries.

    Args:
        query (str): The query to execute.

    Returns:
        list: A list of dictionaries containing the table data.

    Raises:
        ArmisException: If the query fails to execute.
    """
    try:
        credential = DefaultAzureCredential()
        client = LogsQueryClient(credential)
        response = client.query_workspace(
            workspace_id=consts.WORKSPACE_ID,
            query=query,
            timespan=None
        )
    except HttpResponseError as e:
        table_not_exist = "Failed to resolve table expression"
        column_not_exist = "Failed to resolve scalar expression"
        if table_not_exist or column_not_exist in str(e):
            app_logger.warning(
                "TableName provided is not Created or Data is not Ingested.")
            return None, False
        app_logger.error("Error while executing query: {}".format(e))

    if response.status == LogsQueryStatus.SUCCESS:
        app_logger.debug("Query executed successfully.")
        return process_response(response.tables), True
    elif response.status == LogsQueryStatus.PARTIAL:
        app_logger.warning(
            "Query executed partially. Some data might be missing. Partial Error: {}".format(response.partial_error)
            )
        return process_response(response.partial_data), True
    elif response.status == LogsQueryStatus.FAILURE:
        app_logger.error(f"Query failed with status: {response.status}")
        app_logger.error(f"Error: {response.error}")
        raise ArmisException(f"Query failed to execute: {response.error}")


def post_data_to_sentinel(sentinel_client: MicrosoftSentinel, data) -> None:
    """
    Posts data to Sentinel.

    Args:
        data (list): The data to post to Sentinel.

    Returns:
        None

    Raises:
        ArmisException: If the posting of data to Sentinel fails.
    """
    try:
        body = json.dumps(data)
        sentinel_client.post_data(body, consts.ARMIS_ALERTS_TABLE)
        app_logger.info(f"Posting data to Sentinel completed successfully with {len(data)} records.")
    except ArmisException as e:
        raise ArmisException(e)
    except Exception as e:
        app_logger.error(f"Failed to post data to Sentinel: {e}")
        raise ArmisException(f"Failed to post data to Sentinel: {e}")
