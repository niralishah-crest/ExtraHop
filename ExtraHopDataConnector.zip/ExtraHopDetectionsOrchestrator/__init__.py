"""This __init__ file will be called by Http Starter function to pass the data to activity function."""

from azure.durable_functions import DurableOrchestrationContext, Orchestrator
from SharedCode.logger import applogger


def orchestrator_function(context: DurableOrchestrationContext):
    """Get data from durable orchestration context and schedule an activity for execution.

    Args:
        context (df.DurableOrchestrationContext): Context of the durable orchestration execution.

    Returns:
        str: result of Activity function
    """
    applogger.debug("Orchestrator function called.")
    json_data = context.get_input()
    result = yield context.call_activity("ExtraHopSentinelActivity", json_data)
    return result


main = Orchestrator.create(orchestrator_function)
